<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/*
register_sidebars( 1,
array(
'name' => 'custom-footer-gefyra',
'before_widget' => '
<div id="%1$s" class="widget %2$s">',
'after_widget' => '</div>
',
'before_title' => '
<h2 class="widgettitle">',
'after_title' => '</h2>
'
)
);*/