<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/*
add doctor role

add_new_roles();

function add_new_roles() {
    $new_roles = array(
        array(
            'role'      => 'doctor',
            'display'   => 'Γιατρός'
			)

    );
    foreach($new_roles as $role){
        add_role($role['role'], $role['display'], array(
            'edit_published_posts' => true,
            'upload_files' => true,
            'create_product' => true,
            'publish_posts' => true,
            'edit_posts' => true,
            'read' => true,
			'create_posts' => true,
			'manage_options'=>false,
			'update_core' => false,
			'update_plugins' => false,
			'update_themes' => false,
			'install_plugins' => false,
			'install_themes' => false,
			'delete_themes' => false,
			'delete_plugins' => false,
			'edit_plugins' => false,
			'edit_themes' => false,
			'edit_files' => false,
			'edit_users' => false,
			'create_users' => false,
			'delete_users' => false,
			'edit_dashboard' => false,
			'edit_private_pages' => false,
			'edit_private_posts' => false,
			'activate_plugins' => false,
			'delete_others_pages' => false,
			'delete_others_posts' => false,
			'delete_pages' => false,
			'delete_posts' => false,
			'delete_private_pages' => false,
			'delete_private_posts' => false,
			'delete_published_pages' => false,
			'delete_published_posts' => false,
			'edit_dashboard' => false,
			'edit_others_pages' => false,
			'edit_others_posts' => false,
			'edit_theme_options'=>false,
			'moderate_comments'=>false,
			'manage_categories'=>false,

        ));
    }
}



*/
?>